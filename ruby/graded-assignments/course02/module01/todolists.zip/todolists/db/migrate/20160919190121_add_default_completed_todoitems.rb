class AddDefaultCompletedTodoitems < ActiveRecord::Migration
  def change
  end
end
